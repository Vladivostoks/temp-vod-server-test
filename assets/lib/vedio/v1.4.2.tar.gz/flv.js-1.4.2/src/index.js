// entry/index file

// make it compatible with browserify's umd wrapper
module.exports = require('./flv.js').default;
